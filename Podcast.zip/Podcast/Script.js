﻿// Play a specific episode
function playEpisode(episode) {
    currentEpisode = episode;

    // Update UI
    document.getElementById('nowPlayingTitle').textContent = episode.title || 'Unknown Episode';

    // Set audio source DIRECTLY - don't use the proxy for now
    audio.src = episode.audioUrl;

    // Add crossOrigin attribute for CORS
    audio.crossOrigin = "anonymous";

    // Start playing
    audio.play().then(() => {
        document.getElementById('playBtn').textContent = '⏸ Pause';
    }).catch(error => {
        console.error('Playback failed:', error);

        // Try with your proxy endpoint as fallback
        console.log('Trying proxy endpoint as fallback...');
        audio.src = `/api/podcast/stream?audioUrl=${encodeURIComponent(episode.audioUrl)}`;
        audio.play().catch(proxyError => {
            console.error('Proxy playback also failed:', proxyError);
            alert('Failed to play audio. The podcast server may block direct playback. Try clicking the play button manually.');
        });
    });

    // Setup progress updates
    setupProgressBar();
}

// Modified playEpisode function
function playEpisode(episode) {
    currentEpisode = episode;
    document.getElementById('nowPlayingTitle').textContent = episode.title || 'Unknown Episode';

    const audio = document.getElementById('audioPlayer');

    // Try direct play first
    audio.src = episode.audioUrl;
    audio.crossOrigin = "anonymous";

    // Create a test to check if URL is accessible
    checkAudioAccessibility(episode.audioUrl).then(isAccessible => {
        if (isAccessible) {
            // Try to play
            audio.play().catch(e => {
                showPlaybackInstructions();
            });
        } else {
            // URL not accessible, show alternative
            showAlternativePlaybackOptions(episode.audioUrl);
        }
    }).catch(() => {
        // Check failed, try anyway
        audio.play().catch(e => {
            showPlaybackInstructions();
        });
    });

    setupProgressBar();
}

async function checkAudioAccessibility(url) {
    try {
        const response = await fetch(url, { method: 'HEAD' });
        return response.ok;
    } catch {
        return false;
    }
}

function showPlaybackInstructions() {
    const playerContainer = document.getElementById('playerContainer');
    const instructions = document.createElement('div');
    instructions.className = 'playback-instructions';
    instructions.innerHTML = `
        <p><strong>Playback Note:</strong> Some podcasts restrict direct playback.</p>
        <p>Try:</p>
        <ol>
            <li>Click the play button above manually</li>
            <li>Or <a href="${currentEpisode.audioUrl}" target="_blank">open in new tab</a></li>
            <li>Or right-click and "Save audio as" to download</li>
        </ol>
    `;

    // Remove previous instructions if any
    const oldInstructions = playerContainer.querySelector('.playback-instructions');
    if (oldInstructions) oldInstructions.remove();

    playerContainer.appendChild(instructions);
}

function showAlternativePlaybackOptions(audioUrl) {
    const playerContainer = document.getElementById('playerContainer');
    const options = document.createElement('div');
    options.className = 'alternative-options';
    options.innerHTML = `
        <p><strong>Alternative listening options:</strong></p>
        <button onclick="window.open('${audioUrl}', '_blank')">Open in New Tab</button>
        <button onclick="downloadAudio('${audioUrl}')">Download Episode</button>
        <p><small>Some podcast servers block embedded players for copyright reasons.</small></p>
    `;

    playerContainer.appendChild(options);
}

async function downloadAudio(url) {
    try {
        const response = await fetch(`/api/podcast/stream?audioUrl=${encodeURIComponent(url)}`);
        if (response.ok) {
            const blob = await response.blob();
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.download = `${currentEpisode.title || 'podcast'}.mp3`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(downloadUrl);
        }
    } catch (error) {
        // Fallback to direct download
        window.open(url, '_blank');
    }
    
    }
}

