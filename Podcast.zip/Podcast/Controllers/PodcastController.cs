﻿using Microsoft.AspNetCore.Mvc;
using System.ServiceModel.Syndication;
using System.Xml;
using System.Xml.Linq;
using System.Web;

namespace Podcast.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PodcastController : ControllerBase
    {
        /// <summary>
        /// Parse a podcast RSS feed and return episodes
        /// </summary>
        /// <param name="url">The RSS feed URL (e.g., https://feeds.simplecast.com/wgl4xEgL)</param>
        /// <returns>Podcast information and episodes</returns>
        [HttpGet("parse")]
        public IActionResult ParsePodcast([FromQuery] string url)
        {
            if (string.IsNullOrWhiteSpace(url))
                return BadRequest(new { error = "Missing podcast RSS URL." });

            try
            {
                using var reader = XmlReader.Create(url);
                var feed = SyndicationFeed.Load(reader);

                if (feed == null)
                    return BadRequest(new { error = "Unable to read RSS feed." });

                // Extract podcast artwork
                string podcastArtwork = ExtractItunesImage(feed);

                // Extract episodes with more details
                var episodes = feed.Items.Select(item => new
                {
                    id = item.Id ?? Guid.NewGuid().ToString(),
                    title = item.Title?.Text,
                    audioUrl = item.Links.FirstOrDefault(link =>
                        link.RelationshipType == "enclosure" &&
                        (link.MediaType?.Contains("audio") == true ||
                         link.MediaType?.Contains("mpeg") == true ||
                         link.MediaType?.Contains("mp3") == true ||
                         link.MediaType?.Contains("aac") == true))?.Uri?.ToString(),
                    description = item.Summary?.Text,
                    publishedDate = item.PublishDate.UtcDateTime,
                    duration = ExtractItunesDuration(item),
                    explicitContent = ExtractItunesExplicit(item)
                }).Where(ep => !string.IsNullOrEmpty(ep.audioUrl))
                  .ToList();

                return Ok(new
                {
                    podcastTitle = feed.Title?.Text,
                    podcastDescription = feed.Description?.Text,
                    podcastAuthor = ExtractItunesAuthor(feed),
                    podcastArtwork,
                    episodes
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Stream podcast audio (proxy endpoint to handle CORS)
        /// </summary>
        /// <param name="audioUrl">The audio file URL to stream</param>
        /// <returns>Audio stream</returns>
        [HttpGet("stream")]
        public async Task<IActionResult> StreamPodcast([FromQuery] string audioUrl)
        {
            if (string.IsNullOrWhiteSpace(audioUrl))
                return BadRequest(new { error = "Missing audio URL parameter." });

            try
            {
                // Decode URL if it's encoded
                audioUrl = HttpUtility.UrlDecode(audioUrl);

                using var httpClient = new HttpClient();

                // Set a reasonable timeout and user agent
                httpClient.Timeout = TimeSpan.FromSeconds(30);
                httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("PodcastPlayer/1.0");

                var response = await httpClient.GetAsync(audioUrl, HttpCompletionOption.ResponseHeadersRead);

                if (!response.IsSuccessStatusCode)
                {
                    return StatusCode((int)response.StatusCode, new
                    {
                        error = "Failed to fetch audio",
                        statusCode = response.StatusCode,
                        audioUrl = audioUrl
                    });
                }

                // Get content type
                var contentType = response.Content.Headers.ContentType?.MediaType ?? "audio/mpeg";

                // Check if it's actually audio
                if (!contentType.StartsWith("audio/") &&
                    contentType != "application/octet-stream" &&
                    !contentType.Contains("mpeg") &&
                    !contentType.Contains("mp3") &&
                    !contentType.Contains("aac"))
                {
                    return BadRequest(new
                    {
                        error = "URL does not point to an audio file",
                        contentType = contentType,
                        audioUrl = audioUrl
                    });
                }

                // Return the audio stream
                var content = await response.Content.ReadAsStreamAsync();
                return File(content, contentType, enableRangeProcessing: true);
            }
            catch (UriFormatException ex)
            {
                return BadRequest(new
                {
                    error = "Invalid URL format",
                    message = ex.Message,
                    audioUrl = audioUrl
                });
            }
            catch (HttpRequestException ex)
            {
                return BadRequest(new
                {
                    error = "Network error fetching audio",
                    message = ex.Message,
                    audioUrl = audioUrl
                });
            }
            catch (TaskCanceledException ex)
            {
                return BadRequest(new
                {
                    error = "Request timeout",
                    message = "The audio server took too long to respond",
                    audioUrl = audioUrl
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    error = "Unexpected error",
                    message = ex.Message,
                    audioUrl = audioUrl
                });
            }
        }

        // ==================================================================
        // Extract <itunes:image href="...."> manually from ElementExtensions
        // ==================================================================
        private string ExtractItunesImage(SyndicationFeed feed)
        {
            // Look for the iTunes <image> element
            var itunesImage = feed.ElementExtensions
                .Where(ext =>
                    ext.OuterName == "image" &&
                    ext.OuterNamespace == "http://www.itunes.com/dtds/podcast-1.0.dtd")
                .Select(ext =>
                {
                    var el = ext.GetObject<XElement>();
                    return el.Attribute("href")?.Value;
                })
                .FirstOrDefault();

            if (!string.IsNullOrEmpty(itunesImage))
                return itunesImage;

            // Fallback: some feeds use <image url="...">
            var fallbackImage = feed.ElementExtensions
                .Where(ext => ext.OuterName == "image")
                .Select(ext =>
                {
                    var el = ext.GetObject<XElement>();
                    return el.Attribute("url")?.Value
                           ?? el.Attribute("href")?.Value;
                })
                .FirstOrDefault();

            return fallbackImage ?? "";
        }

        // Helper methods for iTunes specific fields
        private string ExtractItunesDuration(SyndicationItem item)
        {
            var durationExt = item.ElementExtensions
                .FirstOrDefault(ext =>
                    ext.OuterName == "duration" &&
                    ext.OuterNamespace == "http://www.itunes.com/dtds/podcast-1.0.dtd");

            if (durationExt != null)
            {
                try
                {
                    return durationExt.GetObject<string>();
                }
                catch
                {
                    return "";
                }
            }

            return "";
        }

        private string ExtractItunesExplicit(SyndicationItem item)
        {
            var explicitExt = item.ElementExtensions
                .FirstOrDefault(ext =>
                    ext.OuterName == "explicit" &&
                    ext.OuterNamespace == "http://www.itunes.com/dtds/podcast-1.0.dtd");

            if (explicitExt != null)
            {
                try
                {
                    return explicitExt.GetObject<string>();
                }
                catch
                {
                    return "";
                }
            }

            return "";
        }

        private string ExtractItunesAuthor(SyndicationFeed feed)
        {
            var authorExt = feed.ElementExtensions
                .FirstOrDefault(ext =>
                    ext.OuterName == "author" &&
                    ext.OuterNamespace == "http://www.itunes.com/dtds/podcast-1.0.dtd");

            if (authorExt != null)
            {
                try
                {
                    return authorExt.GetObject<string>();
                }
                catch
                {
                    return "";
                }
            }

            // Try alternative location for author
            if (feed.Authors != null && feed.Authors.Count > 0)
            {
                return feed.Authors.First().Name ?? "";
            }

            return "";
        }
    }
}